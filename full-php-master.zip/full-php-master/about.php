<html>
	<head>
		<title>Data Dwarves &mdash; Mining For Fun and Profit</title>
		<?php include 'includes\dependencies.php' ?>
	</head>
	<body>
		<?php include 'includes\header.php'; ?>
		<article id="about">
			<h1>Better decisions through data information</h1>
			<p>
				Data Dwarves is an organization that started out as group of students attempting to gather as much knowledge as possible. Patrick, Michael, and Shane being the cofounders quickly found they could help people make better decisions by sharing their accumulated knowledge. Information is a funny thing because it sometimes is overwhelming and unable to make any sense out of. We here at Data Dwarves pride ourselves in providing our information in a manner that is not only easily read but easily shared. 
			</p>
		</article>
		<?php include 'includes\footer.php' ?>
	</body>
</html>