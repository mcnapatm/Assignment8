<link rel="stylesheet" href="styles/core.css" />
<link rel="stylesheet" href="styles/spinner.css" />