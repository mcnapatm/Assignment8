<footer>
	<h1>Contact Us</h1>
		<p>Set up an appointment or simply call for more information</p>
		<p>1-800-829-1040</p>
		<p>ShatrickMolleNamier@DataDwarves.gov</p>
</footer>