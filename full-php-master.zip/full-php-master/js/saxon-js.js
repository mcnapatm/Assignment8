// Saxonica attachment and configuration parameters
// http://www.saxonica.com/html/documentation/using-xsl/embedding/s9api-transformation.html
public class Processor()