<html>
	<head>
		<title>Data Dwarves &mdash; Mining For Fun and Profit</title>
		<?php include 'includes\dependencies.php' ?>
	</head>
	<body>
		<?php include 'includes\header.php'; ?>
		<article>
			<img src="images/Bar graph.png" alt="Bar Graph">
			<img src="images/pie chart.png" alt="Pie Chart">
			<img src="images/line graph.png" alt="Line Graph">
		</article>
		<?php include 'includes\footer.php' ?>
	</body>
</html>